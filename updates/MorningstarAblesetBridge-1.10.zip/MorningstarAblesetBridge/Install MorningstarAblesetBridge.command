#!/bin/bash
# MorningstarAblesetBridge installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the MorningstarAblesetBridge error list:"
  echo "  https://github.com/jonpikereally/MorningstarAblesetBridge/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing MorningstarAblesetBridge…"
mkdir -p ~/Applications || fail MAB-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/MorningstarAblesetBridge.app
ditto --norsrc MorningstarAblesetBridge.app ~/Applications/MorningstarAblesetBridge.app \
  || fail MAB-601 "Couldn't copy MorningstarAblesetBridge into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/MorningstarAblesetBridge.app 2>/dev/null
codesign --force --sign - ~/Applications/MorningstarAblesetBridge.app 2>/dev/null \
  || fail MAB-602 "Couldn't sign MorningstarAblesetBridge for this Mac."
open ~/Applications/MorningstarAblesetBridge.app \
  || fail MAB-603 "MorningstarAblesetBridge was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Look for \"MC4\" in your menu bar (see README.txt to set up the pedal)."
