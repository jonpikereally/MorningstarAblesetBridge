MorningstarAblesetBridge v1.1 — AbleSet song names and play/loop state on a
Morningstar MC4 PRO footswitch (macOS 13+)
https://github.com/jonpikereally/MorningstarAblesetBridge

INSTALL
1. Double-click "Install MorningstarAblesetBridge.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Look for "MC4" in the menu bar.

SET UP
1. Load the AbleSet Bridge bank (bank/AbleSet Bridge.json in the GitHub repo)
   into a bank slot with the Morningstar editor.
2. Connect the MC4 PRO to this Mac over Bluetooth MIDI or USB.
3. In AbleSet, map notes 13 (stop), 15 (previous song) and 16 (next song)
   on channel 1. Don't map CC 110 or CC 111.

PRIVACY
The app talks only to AbleSet on your own Mac (UDP, 127.0.0.1) and to the
pedal over MIDI. No accounts, no analytics. The only thing it fetches from
the internet is a small version file from the GitHub repo above, to see
whether an update exists.
